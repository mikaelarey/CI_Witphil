        <!-- Logo -->
        <a href="#" class="logo"><b>Wit</b>Phil</a>
        <!-- Header Navbar: style can be found in header.less -->