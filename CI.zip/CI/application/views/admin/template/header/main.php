    <header class="main-header">
        
        <!-- LOGO -->
        <?php $this->load->view('admin/template/header/components/logo');?>

        <!-- nav -->
        <?php $this->load->view('admin/template/header/components/nav');?>

    </header>