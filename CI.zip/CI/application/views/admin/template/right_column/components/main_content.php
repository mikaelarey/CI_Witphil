        <section class="content">
          
          <!-- Page -->
          <?php $this->load->view('admin/template/right_column/components/main_content/pages/' . $page); ?>

        </section><!-- /.content -->