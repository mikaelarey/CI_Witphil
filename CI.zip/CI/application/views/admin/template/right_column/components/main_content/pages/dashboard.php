<!-- Small boxes (stat_box) -->
<?php $this->load->view('admin/template/right_column/components/main_content/stat_box'); ?>


<!-- Main row -->
<!-- drag_and_drop -->
<?php //$this->load->view('admin/template/right_column/components/main_content/drag_and_drop'); ?>