      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        

        <!-- content_header -->
        <?php $this->load->view('admin/template/right_column/components/content_header') ?>

        <!-- main_content -->
        <?php $this->load->view('admin/template/right_column/components/main_content') ?>

      </div><!-- /.content-wrapper -->