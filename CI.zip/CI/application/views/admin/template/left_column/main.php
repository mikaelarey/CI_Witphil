      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- user-panel -->
          <?php $this->load->view('admin/template/left_column/components/user-panel'); ?>

          <!-- search-form -->
          <?php $this->load->view('admin/template/left_column/components/search-form'); ?>

          <!-- sidebar-menu  -->
          <?php $this->load->view('admin/template/left_column/components/sidebar-menu'); ?>
          
        </section>
        <!-- /.sidebar -->
      </aside>