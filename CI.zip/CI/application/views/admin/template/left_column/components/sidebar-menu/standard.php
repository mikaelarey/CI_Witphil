            <li>
              <a href="#">
                <i class="<?php echo $menu_icon; ?>"></i> <span><?php echo $menu_name; ?></span>
              </a>
            </li>