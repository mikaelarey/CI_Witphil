      <footer class="main-footer">
        <!-- <div class="pull-right hidden-xs">
          <b>Version</b> 2.0
        </div> -->
        <strong>Copyright &copy; <?php echo date("Y"); ?> <a href="#">SKI Solutions</a>.</strong> All rights reserved.
      </footer>