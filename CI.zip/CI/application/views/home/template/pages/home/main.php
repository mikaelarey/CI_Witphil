    <!-- carousel -->
    
    <?php $this->load->view("home/template/pages/home/components/carousel"); ?>


    <!-- hr -->
    <hr style="border:2rem solid white;">

    <!-- Events -->
    <?php $this->load->view("home/template/pages/home/components/events"); ?>


    <!-- hr -->
    <hr style="border:2rem solid white;">

    <!-- Posts -->
    <?php $this->load->view("home/template/pages/home/components/posts"); ?>