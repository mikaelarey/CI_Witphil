    <!-- Featured post -->
    <div class="container">
        <div class="border border-danger bg-danger">
            <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups"  style="overflow:hidden;">
                <div class="btn-group mr-2" role="group" aria-label="First group">
                    <button type="button" class="btn btn-danger py-3 px-4"><h3>Latest Posts</h3></button>
                </div>
            </div>
        </div>

        <div class="row p-3">
            <div class="col-md-4 col-sm-6 col-xs-12 my-3">
                <div class="card card-hover" style="width:100%;">
                    <img src="<?php echo base_url(); ?>assets/img/post1.jfif" class="card-img-top" alt="..." style="height: 15rem;">
                    <div class="card-body">
                        <h5 class="card-title">Post title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 my-3">
                <div class="card card-hover" style="width:100%;">
                    <img src="<?php echo base_url(); ?>assets/img/post2.jfif" class="card-img-top" alt="..." style="height: 15rem;">
                    <div class="card-body">
                        <h5 class="card-title">Post title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 my-3">
                <div class="card card-hover" style="width:100%;">
                    <img src="<?php echo base_url(); ?>assets/img/post3.jfif" class="card-img-top" alt="..." style="height: 15rem;">
                    <div class="card-body">
                        <h5 class="card-title">Post title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 my-3">
                <div class="card card-hover" style="width:100%;">
                    <img src="<?php echo base_url(); ?>assets/img/post2.jfif" class="card-img-top" alt="..." style="height: 15rem;">
                    <div class="card-body">
                        <h5 class="card-title">Post title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 my-3">
                <div class="card card-hover" style="width:100%;">
                    <img src="<?php echo base_url(); ?>assets/img/post3.jfif" class="card-img-top" alt="..." style="height: 15rem;">
                    <div class="card-body">
                        <h5 class="card-title">Post title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">More Details</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-12 my-3">
                <div class="card card-hover" style="width:100%;">
                    <img src="<?php echo base_url(); ?>assets/img/post1.jfif" class="card-img-top" alt="..." style="height: 15rem;">
                    <div class="card-body">
                        <h5 class="card-title">Post title</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-primary">More Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>