<!-- hr -->
<hr style="border:2rem solid white;">

<!-- Footer -->
<div class="container-fluid" style="background:rgb(0,0,0,0.9);">
    <div class="row p-5 text-center text-white">
        <div class="col-lg-4 col-md-6 col-sm-12">
            <h5 class="mb-5">ABOUT</h5>
            <p style="text-align:justify; padding-left:2px;">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
            <h5 class="mb-5">NAVIGATE</h5>
            <p><a href="#">Home</a></p>
            <p><a href="#">Articles</a></p>
            <p><a href="#">Dining</a></p>
            <p><a href="#">Events</a></p>
            <p><a href="#">About</a></p>
            <p><a href="#">Contact</a></p>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12">
            <h5 class="mb-5">FOLLOW US</h5>
            <span><i class="fa fa-facebook-square" style="font-size:2.5rem;width:4rem;"></i></span>
            <span><i class="fa fa-twitter" style="font-size:2.5rem;width:4rem;"></i></span>
            <span><i class="fa fa-instagram" style="font-size:2.5rem;width:4rem;"></i></span>
            <span><i class="fa fa-google-plus-square" style="font-size:2.5rem;width:4rem;"></i></span>
        </div>
    </div>
</div>

<div class="container-fluid p-5 text-light text-center" style="background:rgb(0,0,0);">
    <p>All Rights Reserved. Copyright &copy; <span class="text-primary">www.witphil.com.</span></p>
</div>